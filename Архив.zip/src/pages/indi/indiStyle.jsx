import styled from 'styled-components'

export const IndiPlaylist = styled.div`
  height: 100vh;
`
