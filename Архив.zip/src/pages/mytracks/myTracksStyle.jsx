import styled from 'styled-components'

export const MyPlaylist = styled.div`
  height: 100vh;
`
