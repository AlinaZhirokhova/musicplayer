import styled from 'styled-components'

export const DayPlaylistTracks = styled.div`
  height: 100vh;
`
