import styled from 'styled-components'

export const DancePlaylist = styled.div`
  height: 100vh;
`
