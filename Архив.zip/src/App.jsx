import { AppRoutes } from './routes.jsx'
import './app.scss'

const App = () => {
  return (
    <AppRoutes />
  )
}

export default App
