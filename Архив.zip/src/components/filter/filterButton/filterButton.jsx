// import { FilterButtonDark, FilterButtonLight } from '../filterStyle'
// import { useContext } from 'react'
// import { ThemeContext } from '../../../context/ThemeContext'

// export const FilterButton = () => {
//     const { currentTheme } = useContext(ThemeContext)

//     if (currentTheme) {
//        return <FilterButtonLight /> 
//     } else {
//        return <FilterButtonDark />
//     }

// }