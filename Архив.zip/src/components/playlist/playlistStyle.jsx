import styled from 'styled-components'

export const PlaylistContainer = styled.div`
  display: flex;
  flex-direction: column;
  overflow-y: auto;
`
