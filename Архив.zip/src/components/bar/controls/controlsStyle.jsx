import styled from 'styled-components'

export const ControlsPlayer = styled.div`
  display: flex;
  flex-direction: row;
  padding: 0 27px 0 31px;
`
