// import styled from 'styled-components'

// export const ProgressBar = styled.input`
//   width: 100%;
//   height: 5px;
//   background: #2e2e2e;
// `
